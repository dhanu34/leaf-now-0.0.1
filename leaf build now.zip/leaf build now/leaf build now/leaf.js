$(document).ready(function(){
    $(".navbar-toggler").click(function(){
        $(".navbar-toggler").toggleClass("change");
    })
})